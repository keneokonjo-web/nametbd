# INTERNAL: Sterling Row website planning (working notes, not for publication)

Status: planning only. Nothing built. Written for Claude's own use in the next session; the founder can read it.

## 1. Goal and success metric
- One job: **maximise free registrations** (name, email, interests). Everything else supports that.
- Secondary: cohort applications (Jan), Founder Kit sales, build-it-for-you enquiries.
- Metric to watch: registrations per 100 visitors, then % who open the welcome email, then % who apply or buy.

## 2. Reference situation (be honest in the next session)
- startuplist.africa could not be read (security checkpoint, then a rate limit). Nothing is known about its layout. Ask the founder for screenshots or notes. Do not guess.
- Dashboard reference (image supplied): three-pane case manager. Left grouped nav (small-caps group labels), middle searchable list with a primary "New" button, right detail view with a serif title, status/meta row, tabs, labelled sections, recent-activity feed, thin rules, tiny status dots, near-monochrome palette.
- Concept Playbook (CLAUDE_WEBSITE_MASTER_PROMPT.md): borrow ingredients, never copy; two or more references per concept; one type pairing, one accent, logo, intro, menu and footer per concept; shared content layer; standalone HTML first; QA with Playwright, axe, 390px overflow check, reduced-motion check.
- Other references still to screenshot when building: a startup directory, an accelerator site, a private-bank site. Choose them with the founder.

## 3. Sitemap
Home (hero + registration) · Course (index, module, lesson) · Tools (index, each tool) · Challenges · Co-founder Board · Startups to Watch (feature, directory later) · Founder Kit (sales page, build-it-for-you, showcase) · Cohort (info, application) · Newsletter archive · About · Legal (privacy, terms, cookies, refunds, affiliate/sponsor disclosure).

## 4. Registration spec (v0)
- Tally (or similar) form embedded or linked. Fields: first name, email, "I am..." (aspiring founder / early founder / other), stage, interests (checkboxes: course, tools, challenges, co-founder board, cohort, kit), country, consent checkbox.
- Consent text must say registering includes the weekly newsletter, with unsubscribe in every email. Check wording with the founder's legal adviser.
- Feeds an email platform (free tier first). Needs an automation (webhook or integration) to add the subscriber. Welcome email with one clear next step. No payment.
- Thank-you page: share link, join the challenge, follow on social.

## 5. Members area (build stage B)
- Auth (email magic link). Roles: member, cohort founder, admin.
- Dashboard layout from the reference image:
  - Left nav groups: LEARN (Course, Tools), BUILD (Challenges, Founder Kit), NETWORK (Co-founder Board, Startups to Watch), PROGRAMME (Cohort, Reviews).
  - Middle: list with search and filter (lessons, challenges, people).
  - Right: detail pane. Serif title, meta row (status, module, tool), tabs (Overview, Worksheet, Notes), recent activity.
- Tables (sketch): members, profiles (co-founder board), lessons, lesson_progress, tool_uses, deck_checks (owner, file, score json, created, expires), applications, challenge_entries, startup_submissions, featured_startups, kit_purchases, review_orders.
- Deck checker: upload PDF, run rubric, store result only, delete file after the stated retention period, rate limit (1 free per 14 days), fair-use cap on paid plans. Needs payments (Stripe) and a privacy policy first.

## 6. Two concepts (not built)
**Concept A: Chambers (classic old-money corporate)**
- Mood: private bank / members' club. Parchment base, ink text, cognac accent, midnight and maroon for statement bands.
- Type: Baskervville for headlines, Alte Haas Grotesk for labels and body.
- Signature moves (from the Playbook): fixed side rail with mark, vertical label and Menu; drawer menu; hero photograph with slow parallax and a mask-rise headline; "Ask" typewriter search pill reused as the registration pill (email field + "Join free"); index list of startups with a cursor-following image preview; sticky stacking cards for "how it works"; giant cropped wordmark in the footer.
- Imagery: warm interiors, dark wood, leather. Logo: serif wordmark in header, stag as favicon and footer mark, SR monogram over the hero.

**Concept B: Ledger (editorial financial press)**
- Mood: broadsheet meets private bank. Midnight base with parchment panels, cognac highlights.
- Type: Baskervville headlines; Alte Haas Bold in wide-tracked caps for section labels; tabular figures for data.
- Signature moves: ticker-style startup strip under the header; multi-column "Startups to Watch" front page; numbered Top 10 list with large numerals; registration as a sticky bottom bar; dashboard preview section using the three-pane layout; corner flourish ornaments on feature panels.
- Logo: sans bold wordmark in header, stag in footer, monogram on the registration thank-you.

Common rules: one accent (cognac); maroon only on statement panels; no second accent; photographs graded low and warm; contrast checked (Parchment on Midnight 14.7:1, Parchment on Maroon 14.8:1, Cognac on Parchment 5.7:1); all hover-only effects need a touch fallback; reduced motion respected.

## 7. Build stages
- A (days): marketing site (home, course index, kit sales page, cohort info page, legal) + Tally registration + email list + analytics. Vercel hosting.
- B (weeks): members area, auth, course content, tools, co-founder board in-app, startup submissions.
- C (later): deck checker, payments, reviews booking, build-it-for-you order form, showcase gallery.
- Do not overbuild. Test manually before software.

## 8. Content and asset needs from the founder
- Client sites for the build-it-for-you showcase, with written permission, URLs and screenshots.
- Real photography or licensed images to replace Pinterest originals before anything is public.
- Copy: registration page, cohort application questions, Kit contents page, FAQ, about page.
- Legal pages from a solicitor or reputable template, reviewed.
- Font licences confirmed (Svenings, Alte Haas). Baskervville is open licence. Neue Haas trial is NOT to be used.

## 9. QA checklist (from the Playbook)
1. Open every page in Chromium via Playwright; fail on any console error or failed request.
2. Screenshot at 1440 and 390 and look at them.
3. scrollWidth <= innerWidth at 390.
4. Tab through: all controls reachable, focus visible.
5. Reduced motion: nothing essential hidden.
6. axe: contrast and labels.
7. Intro and pop-ups dismissible; nothing blocks the registration field.

## 10. Open questions
- Which concept, A or B?
- Who is the visible face, if anyone? Affects About page and credibility.
- Pounds or dollars on pricing pages?
- How many build-it-for-you slots a month?
- Which email platform and form tool?
