STERLING ROW - Brand package (draft 01)
01_Brand_Plan.pdf          The full plan: offer, free layer, Founder Kit (with build-it-for-you), cohort, marketing, timeline, website plan, brand direction, risks.
02_Brand_Lookbook.html     Double-click to open in your browser. Self-contained (images and fonts are inside the file). Private.
03_Social_Graphics/        13 starter graphics (10 portrait 1080x1350, 3 stories 1080x1920). Made with Pinterest originals: private use only until you replace the photos.
04_Brand_Assets/           Stag icon, SR monogram and corner ornament (SVG and PNG, six colours each), two wordmarks, palette.
05_INTERNAL_Website_Planning.md   Working notes for the website build.
Notes: Maroon (#390700) was sampled from your reference poster. Neue Haas trial font is not used. Check font licences for Svenings and Alte Haas before commercial use.
