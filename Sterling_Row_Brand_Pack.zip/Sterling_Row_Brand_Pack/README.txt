STERLING ROW - Brand Pack v0.1 (working concepts)
01_Logos: each logo in 4 versions: black/white transparent PNG, and on white / on black.
  01 Primary stacked + tagline (tagline is a placeholder), 02 stacked, 03 horizontal,
  04 serif wordmark, 05 script wordmark, 06 bold sans wordmark, 07 script + bird,
  08 bird icon (filled), 09 SR monogram, 10 sans lockup.
02_Colour_Packs: three palettes with hex codes.
03_Documents: Brand Starter, Content Plan, Launch Checklist.
Fonts (free, SIL OFL): Cormorant Garamond, Pinyon Script, Inter.
Note: logos are high-res PNG, not vector. Names/domains/trademarks are NOT yet cleared.
